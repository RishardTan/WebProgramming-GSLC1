<!DOCTYPE html>
<html lang="en">
    
<body style="background-color: antiquewhite">
    <div>
        @include('header')
    </div>
    
    <div>
        @yield('body')
    </div>
</body>
</html>