<div class="header" style="text-align: center; width: 100%">
    <div class="text">
        <h1  style="margin-top: 50px; margin-bottom: 50px; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif">Welcome To The Multiplication Table</h1>
    </div>
</div>